#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cassert>

#include <map>
#include <set>
#include <vector>
#include <list>
#include <string>
#include <algorithm>
#include <queue>

using namespace std;

#include "PbSolver.h"
#include "SolverTypes.h"

#include <jni.h>
#include "jminisat.h"

/*
 * Class:     net_sf_javailp_minisat_MiniSat_make
 * Method:    make
 * Signature: ()J
 */
JNIEXPORT jlong JNICALL Java_net_sf_javailp_minisat_MiniSat_make
  (JNIEnv *, jobject){
	PbSolver* solver = new PbSolver();
	return ((jlong)solver);
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_free
 * Method:    free
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_free
  (JNIEnv *, jobject, jlong s){
	delete ((PbSolver*)s);
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_addVariables
 * Method:    addVariables
 * Signature: (JI)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_addVariables
  (JNIEnv *, jobject, jlong s, jint numVars){
	PbSolver* solver = (PbSolver*)s;
	// do nothing
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_addConstraint
 * Method:    addConstraint
 * Signature: (J[I[III)V
 */
JNIEXPORT jboolean JNICALL Java_net_sf_javailp_minisat_MiniSat_addConstraint
  (JNIEnv * env, jobject, jlong s, jintArray coeffs, jintArray vars, jint comp, jint rhs){
	PbSolver* solver = (PbSolver*)s;
	jsize length = env->GetArrayLength(coeffs);
	jint* cs = env->GetIntArrayElements(coeffs, JNI_FALSE);
	jint* vs = env->GetIntArrayElements(vars, JNI_FALSE);

	vec<Lit> ps;
	vec<Int> Cs;
	for(int i=0; i<length; i++){
		int coeff = *(cs+i);
		int var = solver->getVar(*(vs+i));
		ps.push((var > 0)? Lit(var-1) : ~Lit(-var-1));
		Int C = coeff;
		Cs.push(C);
	}
	Int Irhs = rhs;
	int ineq = comp;

	solver->addConstr(ps,Cs,Irhs,ineq);
	ps.clear();
        Cs.clear();

	env->ReleaseIntArrayElements(coeffs,cs,0);
	env->ReleaseIntArrayElements(vars,vs,0);
	return solver->okay();
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_setVar
 * Method:    setVar
 * Signature: (JIZD)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_setVar
  (JNIEnv *, jobject, jlong s, jint var, jboolean phase, jdouble activity){
	PbSolver* solver = (PbSolver*)s;
	Var x = var;
	lbool p = phase?l_True:l_False;
	solver->setPhase(x,p);
        solver->setActivity(x,activity);
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_solveSingle
 * Method:    solveSingle
 * Signature: (J)Z
 */
JNIEXPORT jboolean JNICALL Java_net_sf_javailp_minisat_MiniSat_solveSingle
  (JNIEnv *, jobject, jlong s){
	PbSolver* solver = (PbSolver*)s;
	return solver->solveSingle();
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_solve
 * Method:    solve
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_solve
  (JNIEnv *, jobject, jlong s){
	PbSolver* solver = (PbSolver*)s;
	solver->solve();
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_okay
 * Method:    okay
 * Signature: (J)Z
 */
JNIEXPORT jboolean JNICALL Java_net_sf_javailp_minisat_MiniSat_okay
  (JNIEnv *, jobject, jlong s){
	PbSolver* solver = (PbSolver*)s;
	return solver->okay();
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_valueOf
 * Method:    valueOf
 * Signature: (JI)Z
 */
JNIEXPORT jboolean JNICALL Java_net_sf_javailp_minisat_MiniSat_valueOf
  (JNIEnv *, jobject, jlong s, jint var){
	PbSolver* solver = (PbSolver*)s;
	Var x = var;
	return solver->valueOf(x);
}


/*
 * Class:     net_sf_javailp_minisat_MiniSat_reset
 * Method:    reset
 * Signature: (J)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_reset
  (JNIEnv *, jobject, jlong s){
	PbSolver* solver = (PbSolver*)s;
	solver->reset();
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_setVerbose
 * Method:    setVerbose
 * Signature: (JI)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_setVerbose
  (JNIEnv *, jobject, jlong s, jint v){
	PbSolver* solver = (PbSolver*)s;
        int value = v;
	solver->setVerbose(value);
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_setInc
 * Method:    setInc
 * Signature: (JD)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_setInc
  (JNIEnv *, jobject, jlong s, jdouble v){
	PbSolver* solver = (PbSolver*)s;
        double value = v;
	solver->setInc(value);
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_setDecay
 * Method:    setDecay
 * Signature: (JD)V
 */
JNIEXPORT void JNICALL Java_net_sf_javailp_minisat_MiniSat_setDecay
  (JNIEnv *, jobject, jlong s, jdouble v){
	PbSolver* solver = (PbSolver*)s;
        double value = v;
	solver->setDecay(value);
}

/*
 * Class:     net_sf_javailp_minisat_MiniSat_setObjective
 * Method:    setObjective
 * Signature: (J[I[I)V
 */
JNIEXPORT jboolean JNICALL Java_net_sf_javailp_minisat_MiniSat_setObjective
  (JNIEnv * env, jobject, jlong s, jintArray coeffs, jintArray vars){
        PbSolver* solver = (PbSolver*)s;
	jsize length = env->GetArrayLength(coeffs);
	jint* cs = env->GetIntArrayElements(coeffs, JNI_FALSE);
	jint* vs = env->GetIntArrayElements(vars, JNI_FALSE);

        vec<Lit> ps;
	vec<Int> Cs;
	for(int i=0; i<length; i++){
		int coeff = *(cs+i);
		int var = solver->getVar(*(vs+i));
		ps.push((var > 0)? Lit(var-1) : ~Lit(-var-1));
		Int C = coeff;
		Cs.push(C);
	}

	solver->addGoal(ps,Cs);
        ps.clear();
        Cs.clear();

	env->ReleaseIntArrayElements(coeffs,cs,0);
	env->ReleaseIntArrayElements(vars,vs,0);
	return solver->okay();
}





